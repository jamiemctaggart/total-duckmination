﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class answer : MonoBehaviour
{
    [SerializeField]
    public TextMeshProUGUI textMeshPro;
    private string text = "";
    public static string enemy = "FELINE";
    public static bool update = false;

    void Start()
    {
        updateAnswer("PENETRABLE");
    }

    public void updateAnswer(string newEnemy)
    {
        enemy = newEnemy;
        textMeshPro.text = newEnemy;
    }


    // Update is called once per frame
    void Update()
    {
        if (update)
        {
            update = false;
            updateAnswer(enemy);
        }
    }
}
