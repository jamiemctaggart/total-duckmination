﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class duckController : MonoBehaviour
{
    public GameObject spriteToDuplicate;
    public static int globalPOS = 0;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Vector3 currentPosition = spriteToDuplicate.transform.position;
            GameObject tmpObj = GameObject.Instantiate(spriteToDuplicate, currentPosition, Quaternion.identity) as GameObject;
            globalPOS += 1;
            currentPosition += new Vector3(1f, 0f, 0f);
        }
    }
}
