﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class helpfulBeaver : MonoBehaviour
{
    public Transform player;
    public GameObject SpeechBubble;
    public AudioSource AudioSource;
    private bool done = false;

    // Start is called before the first frame update
    void Start()
    {
        SpeechBubble.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (!done)
        {
            if (GetPlayerInsideArea(15f))
            {
                Debug.Log("HELP");
                AudioSource.Play();
                SpeechBubble.SetActive(true);
                done = true;
            }
        }
        
    }
    bool GetPlayerInsideArea(float Distance)
    {
        bool PlayerInArea = false;

        if (Vector3.Distance(player.position, transform.position) < Distance)
        {
            PlayerInArea = true;
        }
        return PlayerInArea;
    }
}
