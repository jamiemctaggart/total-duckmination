﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class helpfulBeaver : MonoBehaviour
{
    public GameObject PlayerObject;
    public GameObject SpeechBubble;
    public AudioSource AudioSource;
    private bool done = false;

    // Start is called before the first frame update
    void Start()
    {
        SpeechBubble.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (!done)
        {
            if (GetPlayerInsideArea(3f))
            {
                Debug.Log("test");
                AudioSource.Play();
                SpeechBubble.SetActive(true);
                done = true;
            }
        }
        
    }
    bool GetPlayerInsideArea(float Distance)
    {
        bool PlayerInArea = false;
        if (!PlayerObject)
        {
            PlayerObject = GameObject.FindGameObjectWithTag("Player");
        }
        if (Vector3.Distance(PlayerObject.transform.position, new Vector3(3, 2, 2)) < Distance || Vector3.Distance(PlayerObject.transform.position, new Vector3(3, 2, 2)) == Distance)
        {
            PlayerInArea = true;
        }
        return PlayerInArea;
    }
}
