﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;

public class lilDucky : MonoBehaviour
{
    private Rigidbody2D rb;
    public Transform player;
    public int pos;
    private int jumpTimer = 10;
    private float time = 0.0f;

    public float speed;
    private float moveInput;


    // Start is called before the first frame update
    void Start()
    {
        int jumpTimer = 10 + duckController.globalPOS;
        rb = GetComponent<Rigidbody2D>();
        
    }
    IEnumerator DoCheck()
    {
        for (; ; )
        {
            jumpThread();
            yield return new WaitForSeconds(1f);
        }
    }

    void FixedUpdate()
    {
        
    }

    public void jumpThread()
    {
        time = 0.0f;
        if (jumpTimer == 0) jump();
        jumpTimer -= 1;
    }

    void jump()
    { 
        jumpTimer = 10;
        Vector2 movement = new Vector2(rb.velocity.x, rb.velocity.y + 5);
        transform.Translate(movement);
    }

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;
        if (time >= 1) jumpThread();
        Vector2 movement = new Vector2();
        if (Vector3.Distance(player.position, transform.position) > 10d + 5 * pos)
        {
            if (transform.position.x < player.position.x)
                transform.eulerAngles = new Vector3(0, 0, 0);
            else
                transform.eulerAngles = new Vector3(0, 180, 0);
            movement = new Vector2(speed, rb.velocity.y);
            movement *= Time.deltaTime;
            transform.Translate(movement);
        }
    }
}
