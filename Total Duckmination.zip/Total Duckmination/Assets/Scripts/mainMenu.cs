﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class mainMenu : MonoBehaviour
{
    public void playGame()
    {
        Debug.Log("1");
        SceneManager.LoadScene("SampleScene");
    }

    public void exitGame()
    {
        Debug.Log("2");
        Application.Quit();
    }
}