﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sally : MonoBehaviour
{
    public AudioSource AudioSource;
    public Transform player;
    private bool done = false;

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (!done)
        {
            if (GetPlayerInsideArea(15f))
            {
                AudioSource.Play();
                done = true;
            }
        }

    }
    bool GetPlayerInsideArea(float Distance)
    {
        bool PlayerInArea = false;
        
        if (Vector3.Distance(player.position, transform.position) < Distance)
        {
            Debug.Log("HELP");
            PlayerInArea = true;
        }
        return PlayerInArea;
    }
}
