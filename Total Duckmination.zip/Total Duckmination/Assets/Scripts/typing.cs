﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Threading;

public class typing : MonoBehaviour
{
    [SerializeField]
    private TextMeshProUGUI textMeshPro;
    private string text = "";
    private bool enter = true;
    private int pos = 0;

    void Start()
    {
        
    }

    void OnGUI()
    {
        Event e = Event.current;
        if (e.isKey && e.keyCode.ToString() != "None")
        {
            //enter = !enter;
            if (enter == true)
            {
                string chr = e.keyCode.ToString();
                if (answer.enemy.Length != 0 && answer.enemy[pos] == chr[0]) 
                {
                    text += chr;
                    textMeshPro.text = text;
                    pos += 1;
                    Debug.Log(pos);
                    Debug.Log(answer.enemy.Length);
                    if (pos == answer.enemy.Length)
                    {
                        answer.enemy = "FELINE";
                        answer.update = true;
                        text = "";
                        textMeshPro.text = text;
                        pos = 0;
                    }
                }
            }
            
        }
    }
}
